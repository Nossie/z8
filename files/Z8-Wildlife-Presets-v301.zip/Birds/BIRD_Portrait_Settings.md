# Birds Settings

Details on camera configuration for Birds.
