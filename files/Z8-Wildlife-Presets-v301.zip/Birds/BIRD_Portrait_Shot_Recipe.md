# Birds Shot Recipe

Tips and techniques for shooting Birds.
