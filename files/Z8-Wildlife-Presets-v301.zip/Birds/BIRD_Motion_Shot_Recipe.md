# Bird Motion Shot Recipe

Tips for capturing birds in flight.
