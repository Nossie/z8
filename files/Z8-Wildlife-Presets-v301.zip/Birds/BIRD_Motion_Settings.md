# Bird Motion Settings

Details for Bird in Flight.
