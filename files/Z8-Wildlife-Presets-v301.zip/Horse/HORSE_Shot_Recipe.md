# Horse Shot Recipe

Tips and techniques for shooting Horse.
