# Horse Settings

Details on camera configuration for Horse.
