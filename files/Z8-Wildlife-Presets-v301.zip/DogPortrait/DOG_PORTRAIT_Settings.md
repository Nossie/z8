# DogPortrait Settings

Details on camera configuration for DogPortrait.
